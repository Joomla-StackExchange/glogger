DROP TABLE IF EXISTS #__glogger;
DROP TABLE IF EXISTS #__glogger_audit;